Dungeonesque README:

How to Play:

1) Go to https://us.battle.net/account/sc2/starter-edition/
2) Click on Play Free and create a Battle.net account or if you already have an account
3) Go directly to the download
4) Download the Game Installer
5) Launch the client
6) Login to your Battle.net account
7) Go to Custom Games and search for Dungeonesque
8) Set the Game Type to FFA and you are ready to play!
9) Invite friends to play with you

You can also open the Dungeonesque map file
Go to File and publish the map to play custom games